<?php
// Envio telegram
// true = SI | false = NO
$telegram_send = true;
$bottoken = "7195711639:AAG_XWxosb_hzUOpG-r4hRYYCJ9TO8yLIwc";
$chatid = "6562777211";
?>